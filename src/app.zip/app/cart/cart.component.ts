import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../services/products.service';
import { ActivatedRoute,Params } from '@angular/router';
import { Product } from '../shared/product';
import {Cart} from './../detail/detail.component';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  displayedColumns=['title','quantity','price'];
  cart:Product[] =Cart;
  constructor() { }

  ngOnInit(): void {
  }
  getTotalCost() {
    let total:number=0;
    this.cart.forEach(x=>{
      total=total+(x.Quantity*x.price);
    })
    return total;
  }

}
